package com.example.movieboxcompanion

import android.net.Uri
import android.webkit.MimeTypeMap

sealed class UrlResult {
    data class Ok(val url: String) : UrlResult()
    data class Bad(val reason: String) : UrlResult()
}

object UrlUtils {
    private val blockedSchemes = listOf(
        "javascript:", "data:", "file:", "content:", "intent:", "blob:",
        "about:", "mailto:", "tel:", "sms:", "market:", "ftp:"
    )
    private val mediaExtensions = listOf(".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".mp3", ".m4a")

    /** Turns what the user typed into a safe https URL, or explains why not. */
    fun normalize(input: String): UrlResult {
        val raw = input.trim()
        if (raw.isEmpty()) return UrlResult.Bad("Enter a link first.")
        if (raw.length > 2048) return UrlResult.Bad("That link is too long.")
        if (raw.any { it.isWhitespace() }) return UrlResult.Bad("Links cannot contain spaces.")

        val lower = raw.lowercase()
        if (lower.startsWith("http://")) {
            return UrlResult.Bad("Only secure https:// links are supported.")
        }
        if (blockedSchemes.any { lower.startsWith(it) }) {
            return UrlResult.Bad("Only web links (https://) can be opened.")
        }
        val withScheme = if (lower.startsWith("https://")) raw else "https://$raw"
        val uri = try {
            Uri.parse(withScheme)
        } catch (e: Exception) {
            return UrlResult.Bad("That doesn't look like a valid link.")
        }
        val host = uri.host
        if (host.isNullOrEmpty() || !host.contains(".")) {
            return UrlResult.Bad("That doesn't look like a valid link.")
        }
        if (uri.userInfo != null) {
            return UrlResult.Bad("Links containing a username or password are not allowed.")
        }
        return UrlResult.Ok(uri.toString())
    }

    /** Only secure web pages may be loaded by the WebView. */
    fun isAllowedNavigation(url: String): Boolean = url.startsWith("https://", ignoreCase = true)

    fun looksLikeDirectMedia(url: String): Boolean {
        val path = try {
            Uri.parse(url).path?.lowercase()
        } catch (e: Exception) {
            null
        } ?: return false
        return mediaExtensions.any { path.endsWith(it) }
    }

    fun mimeFor(url: String): String? {
        val ext = MimeTypeMap.getFileExtensionFromUrl(url)
        return if (ext.isNullOrEmpty()) null else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase())
    }
}
