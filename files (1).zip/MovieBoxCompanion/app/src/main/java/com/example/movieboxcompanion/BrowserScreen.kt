package com.example.movieboxcompanion

import android.Manifest
import android.app.DownloadManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.view.View
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.net.http.SslError
import android.graphics.Bitmap
import android.webkit.GeolocationPermissions
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch

data class DownloadRequest(
    val url: String,
    val userAgent: String?,
    val contentDisposition: String?,
    val mimeType: String?
)

/** True only if there is a real earlier page (ignores the blank page used by Home). */
private fun WebView.canGoBackReal(): Boolean {
    val list = copyBackForwardList()
    if (list.currentIndex <= 0) return false
    return list.getItemAtIndex(list.currentIndex - 1).url != "about:blank"
}

@Composable
fun BrowserScreen(themeMode: String, onThemeChange: (String) -> Unit) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val clipboard = LocalClipboardManager.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var input by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf<String?>(null) }
    var browsing by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf("") }
    var progress by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var canBack by remember { mutableStateOf(false) }
    var canForward by remember { mutableStateOf(false) }
    var pageError by remember { mutableStateOf<String?>(null) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var pendingDownload by remember { mutableStateOf<DownloadRequest?>(null) }
    var awaitingPermission by remember { mutableStateOf<DownloadRequest?>(null) }
    var showDownloadHelp by remember { mutableStateOf(false) }
    var downloadLinkInput by remember { mutableStateOf("") }
    var downloadLinkError by remember { mutableStateOf<String?>(null) }

    fun say(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    fun hideCustomView() {
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
    }

    fun syncNav(view: WebView) {
        canBack = view.canGoBackReal()
        canForward = view.canGoForward()
        val u = view.url
        if (u != null && u != "about:blank") {
            currentUrl = u
            input = u
        }
    }

    val webView = remember {
        WebView(context).apply {
            settings.apply {
                javaScriptEnabled = true          // needed for modern websites
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                mediaPlaybackRequiresUserGesture = true
                useWideViewPort = true
                loadWithOverviewMode = true
                if (Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            }
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (UrlUtils.isAllowedNavigation(request.url.toString())) return false
                    say("Blocked a link that is not a secure web address.")
                    return true
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    if (url != "about:blank") {
                        loading = true
                        pageError = null
                    }
                    syncNav(view)
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    loading = false
                    syncNav(view)
                }

                override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                    syncNav(view)
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    if (request.isForMainFrame) {
                        loading = false
                        pageError = error.description?.toString()
                            ?: "The page could not be loaded. Check your connection."
                    }
                }

                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                    handler.cancel()
                    loading = false
                    pageError = "This site's security certificate could not be verified, so the page was not loaded."
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress = newProgress
                }

                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    customView = view
                    customViewCallback = callback
                }

                override fun onHideCustomView() {
                    hideCustomView()
                }

                override fun onPermissionRequest(request: PermissionRequest) {
                    val drm = request.resources.contains(PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID)
                    request.deny()
                    say(
                        if (drm) "This page needs protected (DRM) playback, which this app does not enable."
                        else "A permission request from the page was blocked."
                    )
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String,
                    callback: GeolocationPermissions.Callback
                ) {
                    callback.invoke(origin, false, false)
                }
            }

            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                when {
                    url.startsWith("blob:") ->
                        say("This video is streamed in pieces by the website and cannot be saved.")
                    !url.startsWith("https://", ignoreCase = true) ->
                        say("Only secure https downloads are supported.")
                    else -> pendingDownload = DownloadRequest(url, userAgent, contentDisposition, mimeType)
                }
            }
        }
    }

    fun enqueueDownload(req: DownloadRequest) {
        try {
            val name = URLUtil.guessFileName(req.url, req.contentDisposition, req.mimeType)
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val dmRequest = DownloadManager.Request(Uri.parse(req.url)).apply {
                if (!req.mimeType.isNullOrBlank()) setMimeType(req.mimeType)
                CookieManager.getInstance().getCookie(req.url)?.let { addRequestHeader("Cookie", it) }
                if (!req.userAgent.isNullOrBlank()) addRequestHeader("User-Agent", req.userAgent)
                webView.url?.let { addRequestHeader("Referer", it) }
                setTitle(name)
                setDescription("Downloading")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            }
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(dmRequest)
            say("Download started. Check your notifications or the Downloads folder.")
        } catch (e: Exception) {
            say("Could not start the download.")
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val req = awaitingPermission
        awaitingPermission = null
        if (granted && req != null) enqueueDownload(req)
        else say("Storage permission is needed to save files on Android 9 and older.")
    }

    fun requestDownload(req: DownloadRequest) {
        val needsPermission = Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            awaitingPermission = req
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            enqueueDownload(req)
        }
    }

    fun openUrl() {
        when (val result = UrlUtils.normalize(input)) {
            is UrlResult.Bad -> inputError = result.reason
            is UrlResult.Ok -> {
                inputError = null
                input = result.url
                pageError = null
                browsing = true
                focusManager.clearFocus()
                webView.loadUrl(result.url)
            }
        }
    }

    fun goHome() {
        webView.stopLoading()
        webView.loadUrl("about:blank")
        browsing = false
        pageError = null
        loading = false
        canBack = false
        canForward = false
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> webView.onPause()
                Lifecycle.Event.ON_RESUME -> webView.onResume()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            webView.stopLoading()
            webView.destroy()
        }
    }

    BackHandler(enabled = customView != null || browsing) {
        when {
            customView != null -> hideCustomView()
            webView.canGoBackReal() -> webView.goBack()
            else -> goHome()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
                    Column {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            OutlinedTextField(
                                value = input,
                                onValueChange = {
                                    input = it
                                    inputError = null
                                },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                label = { Text("Link") },
                                placeholder = { Text("https://…") },
                                isError = inputError != null,
                                supportingText = inputError?.let { msg -> { Text(msg) } },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Uri,
                                    imeAction = ImeAction.Go
                                ),
                                keyboardActions = KeyboardActions(onGo = { openUrl() })
                            )
                            Button(
                                onClick = { openUrl() },
                                modifier = Modifier.padding(start = 8.dp, top = 8.dp)
                            ) { Text("Open") }
                            IconButton(
                                onClick = { showSettings = true },
                                modifier = Modifier.padding(top = 4.dp)
                            ) { Icon(Icons.Filled.Settings, contentDescription = "Settings") }
                        }
                        AnimatedVisibility(visible = browsing && loading, enter = fadeIn(), exit = fadeOut()) {
                            LinearProgressIndicator(
                                progress = { progress / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            },
            bottomBar = {
                if (browsing) {
                    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { if (webView.canGoBackReal()) webView.goBack() }, enabled = canBack) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                            IconButton(onClick = { webView.goForward() }, enabled = canForward) {
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Forward")
                            }
                            IconButton(onClick = {
                                if (pageError != null && currentUrl.isNotEmpty()) {
                                    pageError = null
                                    webView.loadUrl(currentUrl)
                                } else webView.reload()
                            }) { Icon(Icons.Filled.Refresh, contentDescription = "Reload") }
                            IconButton(onClick = { goHome() }) {
                                Icon(Icons.Filled.Home, contentDescription = "Home")
                            }
                            IconButton(onClick = {
                                if (currentUrl.isNotEmpty()) {
                                    clipboard.setText(AnnotatedString(currentUrl))
                                    say("Link copied.")
                                }
                            }) { Icon(Icons.Filled.ContentCopy, contentDescription = "Copy link") }
                            IconButton(onClick = {
                                if (UrlUtils.looksLikeDirectMedia(currentUrl)) {
                                    pendingDownload = DownloadRequest(
                                        currentUrl, webView.settings.userAgentString, null, UrlUtils.mimeFor(currentUrl)
                                    )
                                } else {
                                    downloadLinkInput = ""
                                    downloadLinkError = null
                                    showDownloadHelp = true
                                }
                            }) { Icon(Icons.Filled.Download, contentDescription = "Download") }
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                if (browsing) {
                    AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
                    AnimatedVisibility(
                        visible = pageError != null,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        ErrorPanel(
                            message = pageError ?: "",
                            onRetry = {
                                pageError = null
                                if (currentUrl.isNotEmpty()) webView.loadUrl(currentUrl)
                            },
                            onHome = { goHome() }
                        )
                    }
                } else {
                    StartScreen()
                }
            }
        }

        customView?.let { cv ->
            AndroidView(
                factory = { cv },
                modifier = Modifier.fillMaxSize().background(Color.Black)
            )
        }
    }

    pendingDownload?.let { req ->
        val name = URLUtil.guessFileName(req.url, req.contentDisposition, req.mimeType)
        AlertDialog(
            onDismissRequest = { pendingDownload = null },
            title = { Text("Download file?") },
            text = {
                Text(
                    "$name\nFrom ${Uri.parse(req.url).host}\n\n" +
                        "Only save files you are authorized to download. " +
                        "Protected (DRM) streams cannot be saved by this app."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingDownload = null
                    requestDownload(req)
                }) { Text("Download") }
            },
            dismissButton = { TextButton(onClick = { pendingDownload = null }) { Text("Cancel") } }
        )
    }

    if (showDownloadHelp) {
        AlertDialog(
            onDismissRequest = { showDownloadHelp = false },
            title = { Text("Download") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "This page is not a direct file, so there is nothing to save from it. " +
                            "Some sites only offer downloads inside their own official app " +
                            "(look for an \"APP\" tag on their Download button). Those cannot " +
                            "be saved from here.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "If you have a direct https link to a file you are allowed to save, " +
                            "paste it here:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = downloadLinkInput,
                        onValueChange = {
                            downloadLinkInput = it
                            downloadLinkError = null
                        },
                        singleLine = true,
                        label = { Text("File link") },
                        isError = downloadLinkError != null,
                        supportingText = downloadLinkError?.let { msg -> { Text(msg) } },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    when (val r = UrlUtils.normalize(downloadLinkInput)) {
                        is UrlResult.Bad -> downloadLinkError = r.reason
                        is UrlResult.Ok -> {
                            showDownloadHelp = false
                            pendingDownload = DownloadRequest(
                                r.url, webView.settings.userAgentString, null, UrlUtils.mimeFor(r.url)
                            )
                        }
                    }
                }) { Text("Download link") }
            },
            dismissButton = { TextButton(onClick = { showDownloadHelp = false }) { Text("Close") } }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Settings") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Theme", fontWeight = FontWeight.Bold)
                    listOf("dark" to "Dark", "light" to "Light", "system" to "Follow system").forEach { (key, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = themeMode == key, onClick = { onThemeChange(key) })
                            Text(label)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Browsing data", fontWeight = FontWeight.Bold)
                    Text(
                        "Clears cache, history, cookies and site data. You will be signed out of websites.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(onClick = {
                        webView.clearCache(true)
                        webView.clearHistory()
                        webView.clearFormData()
                        CookieManager.getInstance().removeAllCookies(null)
                        CookieManager.getInstance().flush()
                        WebStorage.getInstance().deleteAllData()
                        canBack = false
                        canForward = false
                        say("Browsing data cleared.")
                        showSettings = false
                    }) { Text("Clear browsing data") }
                    Spacer(Modifier.height(12.dp))
                    Text("About", fontWeight = FontWeight.Bold)
                    Text(
                        "An independent browser companion. Not affiliated with, endorsed by, or " +
                            "connected to MovieBox. It only displays web pages you open.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
        )
    }
}

@Composable
private fun ErrorPanel(message: String, onRetry: () -> Unit, onHome: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.Warning,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.height(48.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text("Couldn't load this page", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry) { Text("Try again") }
        TextButton(onClick = onHome) { Text("Back to start") }
    }
}

@Composable
private fun StartScreen() {
    val top = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(top, MaterialTheme.colorScheme.background))
        )
    ) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(16.dp))
            Icon(
                Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.height(48.dp)
            )
            Text(
                "MovieBox Companion",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Paste a secure link above and tap Open.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            InfoCard(
                "What it does",
                "Shows the website you open inside the app, so you can browse movie, season and " +
                    "episode pages where the site provides them. Back, Forward, Reload, Home and " +
                    "Copy link controls are at the bottom."
            )
            InfoCard(
                "Downloads",
                "If a page offers a normal downloadable file, or you open a direct file link " +
                    "(for example ending in .mp4), the app asks first and then uses Android's " +
                    "download manager."
            )
            InfoCard(
                "Honest limits",
                "Many sites stream video in protected or chunked form (DRM, blob: or encrypted " +
                    "streams). Those can be watched only if the site and your device allow it, " +
                    "and they cannot be saved. This app does not bypass protection or read " +
                    "private APIs."
            )
            Text(
                "Independent app. Not affiliated with MovieBox.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
            Text(body, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
