package com.example.movieboxcompanion

import android.content.Context

/** Stores the theme choice: "dark" (default), "light" or "system". */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(value) {
            sp.edit().putString("theme", value).apply()
        }
}
