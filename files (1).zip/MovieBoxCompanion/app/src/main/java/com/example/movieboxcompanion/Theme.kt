package com.example.movieboxcompanion

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA78BFA),
    onPrimary = Color(0xFF1A0B3D),
    secondary = Color(0xFF60A5FA),
    onSecondary = Color(0xFF0A1A33),
    background = Color(0xFF0B0B14),
    onBackground = Color(0xFFECECF4),
    surface = Color(0xFF14141F),
    onSurface = Color(0xFFECECF4),
    surfaceVariant = Color(0xFF1E1E2E),
    onSurfaceVariant = Color(0xFFB4B4C8),
    error = Color(0xFFFF6B7A),
    outline = Color(0xFF4A4A68)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF6D3FD6),
    onPrimary = Color.White,
    secondary = Color(0xFF2563EB),
    onSecondary = Color.White,
    background = Color(0xFFF7F6FC),
    onBackground = Color(0xFF14141F),
    surface = Color.White,
    onSurface = Color(0xFF14141F),
    surfaceVariant = Color(0xFFEAE7F7),
    onSurfaceVariant = Color(0xFF45455E),
    error = Color(0xFFB3261E)
)

@Composable
fun CompanionTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
