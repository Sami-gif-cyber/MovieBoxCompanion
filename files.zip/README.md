# MovieBox Companion (independent, unofficial)

A small Android app (Kotlin + Jetpack Compose + WebView) that opens https links inside the app,
with Back / Forward / Reload / Home / Copy-link controls, a loading bar, error screens, a
theme setting, a "clear browsing data" button, and confirmed downloads through Android's
DownloadManager. It is NOT affiliated with MovieBox.

## Status (honest)
- Source code written and checked by reading/XML-validation only.
- NOT compiled and NO APK built yet. The first cloud build is the real test.
  If it fails, copy the red error text from GitHub and send it to Claude to fix.

## What it does NOT do
- It cannot save DRM-protected, encrypted or blob:/chunked streams.
- It does not find hidden video links, use private APIs, or bypass protection.
- DRM playback permission requests from pages are denied (a message is shown).
- Downloads work only for normal https files the website offers, or direct links such as .mp4.

## Build on your phone (no computer, no Android Studio)
1. Create a free account at github.com (phone browser is fine; use "Desktop site" if menus are hidden).
2. Tap + > New repository. Name it MovieBoxCompanion. Tick "Add a README". Create.
3. In the repo tap Add file > Upload files. Choose MovieBoxCompanion.zip (do NOT unzip it).
   Tap Commit changes.
4. Tap Add file > Create new file. In the name box type exactly:
   .github/workflows/build.yml
   (typing the slashes makes the folders). Paste the full contents of build.yml. Commit changes.
5. Open the Actions tab. A run called "Build debug APK" starts by itself (about 5-10 minutes).
   Green tick = success. If it did not start: Actions > Build debug APK > Run workflow.
6. When green, go to the repo main page > Releases (right side or "Releases" link).
   Open the newest release and tap MovieBoxCompanion-debug.apk to download it.
   (Backup: open the run page > Artifacts > MovieBoxCompanion-debug-apk, a zip containing the APK.)

## Install the APK
1. Open the downloaded file from your notifications or the Files / Downloads app.
2. If Android says installs from this source are blocked, tap Settings and allow
   "Install unknown apps" for the app you used (Chrome or Files), then go back and tap Install.
3. If Play Protect warns about an unrecognized app: this is a self-built debug app; choose
   "Install anyway" only if you built it yourself as above.

## Troubleshooting
- Build is red: open the failed step, copy the last ~30 lines of error, send to Claude.
- "App not installed": uninstall any older copy first, or free up storage.
- Can't find .github folder: you must type the full path in the file-name box in step 4.
- Page shows an error: check internet; only https links work.
- Video won't play or can't be downloaded: likely DRM/streamed in pieces (see limits above).
- Downloads on Android 9 or older ask for storage permission; allow it.

## Project layout
settings.gradle.kts, build.gradle.kts, gradle.properties
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/java/com/example/movieboxcompanion/{MainActivity,BrowserScreen,UrlUtils,Prefs,Theme}.kt
app/src/main/res/{values/strings.xml, values/themes.xml, drawable/ic_launcher.xml}
github-workflow/build.yml (copy of the workflow to paste at .github/workflows/build.yml)
